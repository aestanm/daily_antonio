--
-- PostgreSQL database dump
--

\restrict JLGyfVABpnIe8nePSHc4b2sMKWhdSMgwwPb1e8JKdOLmUuLhdkyJpJbmg74f7UB

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: es_administrador(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_administrador() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM usuarios WHERE id = auth.uid() AND rol = 'administrador'
  );
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abonos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.abonos (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    id_tarjeta bigint NOT NULL,
    valor_abono double precision NOT NULL,
    fecha_abono timestamp with time zone NOT NULL,
    saldo_restante double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    medio text DEFAULT 'efectivo'::text NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    nombre text NOT NULL,
    apellido text,
    cedula text,
    telefono text NOT NULL,
    direccion text,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tarjetas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tarjetas (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    doc_cliente text,
    fecha_inicial timestamp with time zone NOT NULL,
    fecha_final timestamp with time zone,
    numero_cuotas integer NOT NULL,
    frecuencia_pago text NOT NULL,
    porcentaje_interes double precision DEFAULT 20.0 NOT NULL,
    valor_prestamo double precision NOT NULL,
    valor_con_intereses double precision NOT NULL,
    saldo double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fecha_eliminacion timestamp with time zone,
    updated_by text,
    id_cliente integer
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id uuid NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    rol text DEFAULT 'cobrador'::text NOT NULL
);


--
-- Data for Name: abonos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.abonos (id, user_id, id_tarjeta, valor_abono, fecha_abono, saldo_restante, date_created, medio, synced, updated_at) FROM stdin;
11	d92f10a1-6db0-4152-ab33-8fa2b958897b	2	120000	2026-09-03 23:16:56.529668+00	0	2026-09-03 23:16:56.529668+00	efectivo	f	2026-09-04 04:16:57.137209+00
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-07 19:06:30.338987+00	230000	2026-08-07 19:06:30.338987+00	efectivo	f	2026-08-08 05:06:30.905528+00
12	d92f10a1-6db0-4152-ab33-8fa2b958897b	3	130000	2026-09-03 23:17:07.057762+00	170000	2026-09-03 23:17:07.057762+00	efectivo	f	2026-09-04 04:17:07.540679+00
10	d92f10a1-6db0-4152-ab33-8fa2b958897b	7	10000	2026-08-13 00:00:00+00	110000	2026-08-16 16:08:33.194031+00	efectivo	f	2026-08-16 21:08:54.349619+00
5	d92f10a1-6db0-4152-ab33-8fa2b958897b	4	64000	2026-08-16 11:25:35.868256+00	1856000	2026-08-16 11:25:35.868256+00	efectivo	f	2026-08-16 16:25:37.001367+00
6	d92f10a1-6db0-4152-ab33-8fa2b958897b	4	64000	2026-08-16 14:15:46.696288+00	1792000	2026-08-16 14:15:46.696288+00	efectivo	f	2026-08-16 19:15:47.923682+00
8	d92f10a1-6db0-4152-ab33-8fa2b958897b	7	20000	2026-08-16 10:09:36.481124+00	90000	2026-08-16 10:10:18.49448+00	efectivo	f	2026-08-16 20:10:19.163587+00
9	d92f10a1-6db0-4152-ab33-8fa2b958897b	7	10000	2026-08-16 16:07:56.73356+00	80000	2026-08-16 16:08:03.599929+00	nequi	f	2026-08-16 21:08:25.369284+00
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-08 20:30:20.461655+00	220000	2026-08-08 20:30:20.461655+00	efectivo	f	2026-08-09 06:30:20.889808+00
3	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-08 20:30:44.841467+00	210000	2026-08-08 20:30:44.841467+00	efectivo	f	2026-08-09 06:30:45.448449+00
4	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-10 23:45:32.354717+00	200000	2026-08-10 23:45:32.354717+00	efectivo	f	2026-08-11 09:45:32.744011+00
7	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	200000	2026-08-16 14:48:30.258169+00	0	2026-08-16 14:48:30.258169+00	efectivo	f	2026-08-16 19:48:30.784577+00
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes (id, user_id, nombre, apellido, cedula, telefono, direccion, date_created, last_update, synced, updated_at) FROM stdin;
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	rony	\N	72253102	3146832001	manzana 3 lote 28	2026-08-07 19:06:06+00	2026-08-09 01:42:59.976965+00	f	2026-08-08 05:06:07.830848+00
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	ivon linero	\N	123456	 3207539271	kr 2sur #42_31 	2026-08-08 20:00:46.125019+00	2026-08-08 20:00:46.12502+00	f	2026-08-09 01:00:47.210779+00
4	d92f10a1-6db0-4152-ab33-8fa2b958897b	Carlos perro 	\N	72173951	3004944615	kra 14a#85a10	2026-08-10 17:50:55.742154+00	2026-08-10 17:50:55.742156+00	f	2026-08-10 22:50:57.102508+00
5	d92f10a1-6db0-4152-ab33-8fa2b958897b	iyaris taxi 244	\N	72198535	3052811186	calle 87#26-47,olivos	2026-08-10 18:10:31.785804+00	2026-08-10 18:10:31.785805+00	f	2026-08-10 23:10:33.041597+00
6	d92f10a1-6db0-4152-ab33-8fa2b958897b	James repuesto 	\N	12345	3024442394	call49#1b-125	2026-08-11 12:05:26.021104+00	2026-08-11 12:05:26.021104+00	f	2026-08-11 17:05:27.189702+00
7	d92f10a1-6db0-4152-ab33-8fa2b958897b	tarjeta de pruebas	\N	951014			2026-08-16 15:09:04.031117+00	2026-08-16 15:09:04.031119+00	f	2026-08-16 20:09:04.816965+00
3	d92f10a1-6db0-4152-ab33-8fa2b958897b	Roberto pugliese	\N	800504	3113894073	cayenas bloque A4 	2026-08-09 13:14:57+00	2026-08-16 15:09:23.33708+00	f	2026-08-09 23:14:58.358462+00
\.


--
-- Data for Name: tarjetas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tarjetas (id, user_id, doc_cliente, fecha_inicial, fecha_final, numero_cuotas, frecuencia_pago, porcentaje_interes, valor_prestamo, valor_con_intereses, saldo, date_created, last_update, synced, updated_at, fecha_eliminacion, updated_by, id_cliente) FROM stdin;
5	d92f10a1-6db0-4152-ab33-8fa2b958897b	72198535	2026-08-10 18:06:56.424383+00	\N	60	Diario	20	1000000	1200000	1200000	2026-08-10 18:10:31.801895+00	2026-08-10 18:10:31.801899+00	f	2026-08-10 23:10:33.575274+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	5
6	d92f10a1-6db0-4152-ab33-8fa2b958897b	12345	2026-08-11 12:03:29.527308+00	\N	12	Semanal	10	4000000	4400000	4400000	2026-08-11 12:05:26.044515+00	2026-08-11 12:05:26.044528+00	f	2026-08-11 17:05:27.450643+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	6
4	d92f10a1-6db0-4152-ab33-8fa2b958897b	72173951	2026-08-10 12:48:48+00	\N	30	Diario	20	1600000	1920000	1792000	2026-08-10 12:50:55+00	2026-08-16 14:15:46.696288+00	f	2026-08-10 22:50:57.408369+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	4
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	72253102	2026-08-04 14:00:00+00	2026-08-16 14:48:30.258169+00	24	Diario	20	200000	240000	0	2026-08-08 15:42:59+00	2026-08-16 14:48:30.258169+00	f	2026-08-08 05:06:08.11715+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	1
7	d92f10a1-6db0-4152-ab33-8fa2b958897b	951014	2026-08-16 10:08:36+00	\N	30	Diario	20	100000	120000	80000	2026-08-16 10:09:04+00	2026-08-16 16:08:33.259545+00	f	2026-08-16 20:09:05.082658+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	7
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	123456	2026-08-08 14:57:03+00	2026-09-03 23:16:56.529668+00	1	Mensual	20	100000	120000	0	2026-08-08 15:00:46+00	2026-09-03 23:16:56.529668+00	f	2026-08-09 01:00:47.453144+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	2
3	d92f10a1-6db0-4152-ab33-8fa2b958897b	800504	2026-08-09 13:10:16+00	\N	2	Mensual	20	250000	300000	170000	2026-08-09 13:14:57+00	2026-09-03 23:17:07.057762+00	f	2026-08-09 23:14:58.631829+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b	3
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, nombre, email, activo, created_at, rol) FROM stdin;
d92f10a1-6db0-4152-ab33-8fa2b958897b	Antonio	aestan0511@gmail.com	t	2026-08-07 01:27:59+00	administrador
\.


--
-- Name: abonos abonos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: tarjetas tarjetas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: idx_tarjetas_id_cliente; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tarjetas_id_cliente ON public.tarjetas USING btree (id_cliente);


--
-- Name: abonos abonos_id_tarjeta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_id_tarjeta_fkey FOREIGN KEY (id_tarjeta) REFERENCES public.tarjetas(id);


--
-- Name: abonos abonos_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: clientes clientes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: tarjetas tarjetas_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.clientes(id);


--
-- Name: tarjetas tarjetas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: usuarios usuarios_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: abonos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.abonos ENABLE ROW LEVEL SECURITY;

--
-- Name: abonos abonos_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY abonos_acceso_por_rol ON public.abonos USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: clientes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;

--
-- Name: clientes clientes_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clientes_acceso_por_rol ON public.clientes USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: tarjetas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tarjetas ENABLE ROW LEVEL SECURITY;

--
-- Name: tarjetas tarjetas_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tarjetas_acceso_por_rol ON public.tarjetas USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: usuarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;

--
-- Name: usuarios usuarios_lectura_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuarios_lectura_por_rol ON public.usuarios FOR SELECT USING (((auth.uid() = id) OR public.es_administrador()));


--
-- PostgreSQL database dump complete
--

\unrestrict JLGyfVABpnIe8nePSHc4b2sMKWhdSMgwwPb1e8JKdOLmUuLhdkyJpJbmg74f7UB

