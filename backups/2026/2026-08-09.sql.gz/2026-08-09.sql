--
-- PostgreSQL database dump
--

\restrict AznWgCvqxMWVEoKptoTAa3MhGYlVTaLJ9R7fevEuvc7HIpIrH2l6d0jfyNmo7WP

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: es_administrador(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_administrador() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM usuarios WHERE id = auth.uid() AND rol = 'administrador'
  );
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abonos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.abonos (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    id_tarjeta bigint NOT NULL,
    valor_abono double precision NOT NULL,
    fecha_abono timestamp with time zone NOT NULL,
    saldo_restante double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    medio text DEFAULT 'efectivo'::text NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    nombre text NOT NULL,
    apellido text,
    cedula text NOT NULL,
    telefono text NOT NULL,
    direccion text,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tarjetas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tarjetas (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    doc_cliente text NOT NULL,
    fecha_inicial timestamp with time zone NOT NULL,
    fecha_final timestamp with time zone,
    numero_cuotas integer NOT NULL,
    frecuencia_pago text NOT NULL,
    porcentaje_interes double precision DEFAULT 20.0 NOT NULL,
    valor_prestamo double precision NOT NULL,
    valor_con_intereses double precision NOT NULL,
    saldo double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fecha_eliminacion timestamp with time zone,
    updated_by text
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id uuid NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    rol text DEFAULT 'cobrador'::text NOT NULL
);


--
-- Data for Name: abonos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.abonos (id, user_id, id_tarjeta, valor_abono, fecha_abono, saldo_restante, date_created, medio, synced, updated_at) FROM stdin;
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-08 00:06:30.338987+00	230000	2026-08-08 00:06:30.338987+00	efectivo	f	2026-08-08 05:06:30.905528+00
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-09 01:30:20.461655+00	230000	2026-08-09 01:30:20.461655+00	efectivo	f	2026-08-09 06:30:20.889808+00
3	d92f10a1-6db0-4152-ab33-8fa2b958897b	1	10000	2026-08-09 01:30:44.841467+00	220000	2026-08-09 01:30:44.841467+00	efectivo	f	2026-08-09 06:30:45.448449+00
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes (id, user_id, nombre, apellido, cedula, telefono, direccion, date_created, last_update, synced, updated_at) FROM stdin;
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	rony	\N	72253102	3146832001	manzana 3 lote 28	2026-08-07 19:06:06+00	2026-08-09 01:42:59.976965+00	f	2026-08-08 05:06:07.830848+00
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	ivon linero	\N	123456	 3207539271	kr 2sur #42_31 	2026-08-08 20:00:46.125019+00	2026-08-08 20:00:46.12502+00	f	2026-08-09 01:00:47.210779+00
\.


--
-- Data for Name: tarjetas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tarjetas (id, user_id, doc_cliente, fecha_inicial, fecha_final, numero_cuotas, frecuencia_pago, porcentaje_interes, valor_prestamo, valor_con_intereses, saldo, date_created, last_update, synced, updated_at, fecha_eliminacion, updated_by) FROM stdin;
2	d92f10a1-6db0-4152-ab33-8fa2b958897b	123456	2026-08-08 19:57:03.35095+00	\N	1	Mensual	20	100000	120000	120000	2026-08-08 20:00:46.141273+00	2026-08-08 20:00:46.141277+00	f	2026-08-09 01:00:47.453144+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b
1	d92f10a1-6db0-4152-ab33-8fa2b958897b	72253102	2026-08-05 00:00:00+00	\N	24	Diario	20	200000	240000	240000	2026-08-09 01:42:59.962934+00	2026-08-09 01:42:59.962936+00	f	2026-08-08 05:06:08.11715+00	\N	d92f10a1-6db0-4152-ab33-8fa2b958897b
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, nombre, email, activo, created_at, rol) FROM stdin;
d92f10a1-6db0-4152-ab33-8fa2b958897b	Antonio	aestan0511@gmail.com	t	2026-08-07 01:27:59+00	administrador
\.


--
-- Name: abonos abonos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: tarjetas tarjetas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: abonos abonos_id_tarjeta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_id_tarjeta_fkey FOREIGN KEY (id_tarjeta) REFERENCES public.tarjetas(id);


--
-- Name: abonos abonos_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: clientes clientes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: tarjetas tarjetas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: usuarios usuarios_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: abonos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.abonos ENABLE ROW LEVEL SECURITY;

--
-- Name: abonos abonos_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY abonos_acceso_por_rol ON public.abonos USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: clientes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;

--
-- Name: clientes clientes_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clientes_acceso_por_rol ON public.clientes USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: tarjetas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tarjetas ENABLE ROW LEVEL SECURITY;

--
-- Name: tarjetas tarjetas_acceso_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tarjetas_acceso_por_rol ON public.tarjetas USING (((user_id = auth.uid()) OR public.es_administrador())) WITH CHECK (((user_id = auth.uid()) OR public.es_administrador()));


--
-- Name: usuarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;

--
-- Name: usuarios usuarios_lectura_por_rol; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuarios_lectura_por_rol ON public.usuarios FOR SELECT USING (((auth.uid() = id) OR public.es_administrador()));


--
-- PostgreSQL database dump complete
--

\unrestrict AznWgCvqxMWVEoKptoTAa3MhGYlVTaLJ9R7fevEuvc7HIpIrH2l6d0jfyNmo7WP

