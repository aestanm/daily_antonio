--
-- PostgreSQL database dump
--

\restrict IlepNf9NX0afrQ3RAxBxqrUZVeaNKw3czzfVScGFHk8UIlaJB0MLD1fpkegeHFO

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abonos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.abonos (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    id_tarjeta bigint NOT NULL,
    valor_abono double precision NOT NULL,
    fecha_abono timestamp with time zone NOT NULL,
    saldo_restante double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    medio text DEFAULT 'efectivo'::text NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    nombre text NOT NULL,
    apellido text,
    cedula text NOT NULL,
    telefono text NOT NULL,
    direccion text,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tarjetas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tarjetas (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    doc_cliente text NOT NULL,
    fecha_inicial timestamp with time zone NOT NULL,
    fecha_final timestamp with time zone,
    numero_cuotas integer NOT NULL,
    frecuencia_pago text NOT NULL,
    porcentaje_interes double precision DEFAULT 20.0 NOT NULL,
    valor_prestamo double precision NOT NULL,
    valor_con_intereses double precision NOT NULL,
    saldo double precision NOT NULL,
    date_created timestamp with time zone NOT NULL,
    last_update timestamp with time zone NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fecha_eliminacion timestamp with time zone,
    updated_by text
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id uuid NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    rol text DEFAULT 'cobrador'::text NOT NULL
);


--
-- Data for Name: abonos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.abonos (id, user_id, id_tarjeta, valor_abono, fecha_abono, saldo_restante, date_created, medio, synced, updated_at) FROM stdin;
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes (id, user_id, nombre, apellido, cedula, telefono, direccion, date_created, last_update, synced, updated_at) FROM stdin;
\.


--
-- Data for Name: tarjetas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tarjetas (id, user_id, doc_cliente, fecha_inicial, fecha_final, numero_cuotas, frecuencia_pago, porcentaje_interes, valor_prestamo, valor_con_intereses, saldo, date_created, last_update, synced, updated_at, fecha_eliminacion, updated_by) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, nombre, email, activo, created_at, rol) FROM stdin;
c53b5032-1a1c-4d9c-a782-3e679f1e59dc	Antonio	aestan0511@gmail.com	t	2026-08-07 01:27:59+00	administrador
\.


--
-- Name: abonos abonos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: tarjetas tarjetas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: abonos abonos_id_tarjeta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_id_tarjeta_fkey FOREIGN KEY (id_tarjeta) REFERENCES public.tarjetas(id);


--
-- Name: abonos abonos_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abonos
    ADD CONSTRAINT abonos_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: clientes clientes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: tarjetas tarjetas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarjetas
    ADD CONSTRAINT tarjetas_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: usuarios usuarios_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: abonos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.abonos ENABLE ROW LEVEL SECURITY;

--
-- Name: clientes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;

--
-- Name: tarjetas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tarjetas ENABLE ROW LEVEL SECURITY;

--
-- Name: usuarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict IlepNf9NX0afrQ3RAxBxqrUZVeaNKw3czzfVScGFHk8UIlaJB0MLD1fpkegeHFO

